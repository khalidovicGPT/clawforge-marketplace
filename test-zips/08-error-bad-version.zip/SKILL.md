---
name: bad-version-skill
version: v1.0
description: "Un skill avec une mauvaise version"
---

# Bad Version
