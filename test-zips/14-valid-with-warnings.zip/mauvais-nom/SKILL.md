---
name: bon-nom
version: 1.0.0
description: "Un skill avec des warnings"
---

# Skill
