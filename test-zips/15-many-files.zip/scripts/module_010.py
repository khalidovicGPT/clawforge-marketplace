# Module 10
def func_10():
    return 10
