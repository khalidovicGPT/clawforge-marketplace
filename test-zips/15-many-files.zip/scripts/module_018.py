# Module 18
def func_18():
    return 18
