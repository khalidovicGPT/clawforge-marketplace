# Module 24
def func_24():
    return 24
