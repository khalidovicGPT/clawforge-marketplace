# Module 6
def func_6():
    return 6
