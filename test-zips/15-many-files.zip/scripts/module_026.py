# Module 26
def func_26():
    return 26
