# Module 5
def func_5():
    return 5
