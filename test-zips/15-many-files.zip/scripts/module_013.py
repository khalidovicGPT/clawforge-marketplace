# Module 13
def func_13():
    return 13
