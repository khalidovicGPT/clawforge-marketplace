# Module 14
def func_14():
    return 14
