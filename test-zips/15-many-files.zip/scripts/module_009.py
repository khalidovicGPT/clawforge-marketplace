# Module 9
def func_9():
    return 9
