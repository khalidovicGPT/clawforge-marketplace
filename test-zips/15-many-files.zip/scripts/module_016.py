# Module 16
def func_16():
    return 16
