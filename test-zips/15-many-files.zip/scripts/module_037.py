# Module 37
def func_37():
    return 37
