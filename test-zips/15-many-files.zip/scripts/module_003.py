# Module 3
def func_3():
    return 3
