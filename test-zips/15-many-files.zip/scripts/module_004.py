# Module 4
def func_4():
    return 4
