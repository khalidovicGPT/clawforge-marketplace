# Module 12
def func_12():
    return 12
