# Module 17
def func_17():
    return 17
