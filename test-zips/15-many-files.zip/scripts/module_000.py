# Module 0
def func_0():
    return 0
