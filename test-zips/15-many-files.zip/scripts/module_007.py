# Module 7
def func_7():
    return 7
