# Module 21
def func_21():
    return 21
