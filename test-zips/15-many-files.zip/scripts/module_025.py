# Module 25
def func_25():
    return 25
