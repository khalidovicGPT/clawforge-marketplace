# Module 27
def func_27():
    return 27
