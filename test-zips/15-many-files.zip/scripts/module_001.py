# Module 1
def func_1():
    return 1
