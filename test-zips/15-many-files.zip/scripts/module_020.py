# Module 20
def func_20():
    return 20
