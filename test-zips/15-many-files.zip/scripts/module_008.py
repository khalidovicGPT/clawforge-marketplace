# Module 8
def func_8():
    return 8
