# Module 2
def func_2():
    return 2
