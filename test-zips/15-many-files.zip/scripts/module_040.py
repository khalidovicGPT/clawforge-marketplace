# Module 40
def func_40():
    return 40
