# Module 36
def func_36():
    return 36
