# Email Assistant

Documentation complete du skill.

## Quick Start
1. Installer les dependances
2. Configurer SMTP
3. Utiliser via agent
