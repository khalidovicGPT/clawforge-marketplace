# Mon Skill

Pas de frontmatter YAML ici.
Juste du Markdown.
