---
name: test-skill
version: 1.0.0
description: "Test
  invalid: [yaml: broken
    missing: closing bracket
---

# Test
