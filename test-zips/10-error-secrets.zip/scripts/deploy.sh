#!/bin/bash
# Script de deploiement
export GITHUB_TOKEN="ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefgh12345678"
echo "Deploying..."
