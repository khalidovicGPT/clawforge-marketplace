#!/usr/bin/env python3
# Configuration avec des secrets en dur (MAUVAISE PRATIQUE)

api_key = "sk_live_51ABC123DEF456GHI789JKL"
secret_key = "whsec_abcdefghijklmnopqrstuvwxyz12345"
password = "SuperSecret123!@#"
