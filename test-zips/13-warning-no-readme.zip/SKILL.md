---
name: email-assistant
version: 1.0.0
description: "Automatise l'envoi d'emails via SMTP"
author: "ClawForge Test"
license: "MIT"
homepage: "https://github.com/clawforge/email-assistant"
tested_on:
  - platform: "Linux"
    node: "v22.x"
    openclaw: "2026.2.x"
metadata:
  openclaw:
    emoji: "📧"
    requires:
      bins: ["python3", "curl"]
      packages: ["requests"]
---

# Email Assistant

Un skill qui automatise l'envoi d'emails via SMTP.

## Fonctionnalites
- Envoi d'emails simples
- Templates HTML
- Pieces jointes

## Installation
```bash
pip install requests
```

## Utilisation
```
Agent, envoie un email a test@example.com avec le sujet "Hello"
```
