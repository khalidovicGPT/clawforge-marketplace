# RFC 5321 - Simple Mail Transfer Protocol

Reference technique.