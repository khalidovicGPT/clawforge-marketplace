#!/usr/bin/env python3
"""Script d'envoi d'emails."""
import smtplib
from email.mime.text import MIMEText

def send_email(to, subject, body):
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['To'] = to
    # Configuration SMTP via variables d'environnement
    print(f"Email envoye a {to}")

if __name__ == "__main__":
    send_email("test@example.com", "Hello", "World")
